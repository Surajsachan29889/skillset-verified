module.exports = {
    SEED_PHRASE: 'name illness host either they desk start december claw siren buzz soft',
    INFURA_KEY: 'a9f5ff53637b4ff7a44750eb997bba63'
  };